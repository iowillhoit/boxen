# Total Finder Puppet Module for Boxen

Total Finder brings tabs to your native Finder and more!

http://totalfinder.binaryage.com/

## Usage

```puppet
include totalfinder
```

## Required Puppet Modules

* `boxen`

## Development

Write code. Run `script/cibuild` to test it. Check the `script`
directory for other useful tools.
